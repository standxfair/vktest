self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "474b14dca7010cfc23971a1b753a8100",
    "url": "./index.html"
  },
  {
    "revision": "873fe3fdd05978b2844e",
    "url": "./static/css/2.d0a510e7.chunk.css"
  },
  {
    "revision": "088046012d9fd4af1547",
    "url": "./static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "873fe3fdd05978b2844e",
    "url": "./static/js/2.3e0682de.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.3e0682de.chunk.js.LICENSE.txt"
  },
  {
    "revision": "088046012d9fd4af1547",
    "url": "./static/js/main.d896cef8.chunk.js"
  },
  {
    "revision": "28a1fe464fabc2af7f3f",
    "url": "./static/js/runtime-main.a5719b10.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "./static/media/persik.4e1ec840.png"
  }
]);